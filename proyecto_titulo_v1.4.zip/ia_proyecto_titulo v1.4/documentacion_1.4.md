================================================================================
     LOGIN CON PANEL DE ADMINISTRACIÓN Y SUPERVISIÓN — DOCUMENTACIÓN v1.4
================================================================================
Proyecto:   Sistema de login con roles, aislamiento por empresa, visualización
            de cámaras en directo y recuperación de contraseña simulada.
Versión:    1.4
Fecha:      Octubre 2026
Stack:      Python 3.12 · FastAPI · SQLAlchemy · bcrypt · PyJWT · Jinja2
Frontend:   HTML + CSS + JS puro (sin frameworks) + hls.js (solo HLS)
Base datos: SQLite (login.db)
Seguridad:  JWT en cookie httpOnly + validación en servidor por rol
Generado:   Claude (Anthropic)
================================================================================


================================================================================
1. RESUMEN EJECUTIVO (Novedades v1.4)
================================================================================

La versión 1.4 incorpora un flujo completo de recuperación de contraseña sin 
dependencias externas de correo electrónico (sin Gmail, SendGrid ni ningún 
proveedor SMTP). El código de verificación se genera en el servidor y se 
devuelve directamente en la respuesta JSON para mostrarse en la interfaz, lo 
que permite simular el flujo completo en un entorno de desarrollo o demo. Se 
incluyeron las medidas de seguridad pertinentes para que el mecanismo sea apto 
para producción con mínimos ajustes futuros.

Cambios principales:

  1. Recuperación de contraseña simulada
     El usuario solicita un código de 6 dígitos, el cual se muestra en pantalla.
     El código expira a los 15 minutos y se borra de la base de datos al usarse.

  2. Prevención de enumeración de usuarios
     Si se ingresa un correo no registrado, el sistema responde de forma genérica
     (HTTP 200 con "codigo_simulado": null) para no revelar si el email existe.

  3. Nuevas funciones en la Base de Datos
     Se añadieron las columnas reset_code y reset_code_expira a la tabla usuarios,
     junto con las funciones guardar_codigo_reset() y actualizar_password().

Alcance v1.4:

  - Login de usuarios existentes.
  - Panel admin: gestión de usuarios y empresas.
  - Panel supervisor: gestión de departamentos y cámaras.
  - Visualización de cámaras en modal (HLS + MJPEG).
  - Recuperación de contraseña mediante código simulado.

Fuera de alcance (para futuras versiones):

  - Envío real de correos electrónicos (SMTP).
  - Edición/desactivación de usuarios.
  - Conversión RTSP → HLS dentro del backend.
  - Paginación en listados.
  - Tests automatizados.
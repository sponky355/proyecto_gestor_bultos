import random
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

import bcrypt
import cv2
import jwt
import numpy as np
from fastapi import (
    Depends,
    FastAPI,
    File,
    Form,
    HTTPException,
    Request,
    Response,
    UploadFile,
    status,
)
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from ultralytics import YOLO

from base_de_datos.conexion import SesionLocal, crear_tablas, obtener_sesion
from base_de_datos.empresas import (
    crear_empresa,
    listar_empresas,
    obtener_por_id as obtener_empresa_por_id,
    obtener_por_nombre as obtener_empresa_por_nombre,
)
from base_de_datos.usuarios import (
    actualizar_password,
    crear_usuario,
    guardar_codigo_reset,
    listar_usuarios,
    listar_usuarios_por_empresa,
    obtener_por_email,
    obtener_por_id,
)
from base_de_datos.camaras import (
    crear_camara,
    listar_por_empresa as listar_camaras_por_empresa,
    listar_por_departamento as listar_camaras_por_departamento,
    listar_por_usuario as listar_camaras_por_usuario,
    obtener_por_id as obtener_camara_por_id,
)
from base_de_datos.departamentos import (
    crear_departamento,
    listar_por_empresa as listar_departamentos_por_empresa,
    obtener_por_id as obtener_departamento_por_id,
)

# ============================================================
# Modelo YOLO — carga única al importar el módulo
# ============================================================
modelo_yolo = YOLO("yolov8n.pt")

# ============================================================
# Configuración
# ============================================================
SECRETO_JWT = "cambia-esto-en-produccion"
ALGORITMO = "HS256"
MINUTOS_EXPIRACION = 60
MINUTOS_RESET = 15

ROLES_VALIDOS = {"admin", "supervisor", "usuario"}

BASE_DIR = Path(__file__).resolve().parent
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))

app = FastAPI(title="Login Simple + Admin")
app.mount(
    "/static",
    StaticFiles(directory=str(BASE_DIR / "static")),
    name="static",
)


# ============================================================
# Utilidades de seguridad
# ============================================================
def hashear_password(password: str) -> str:
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()


def verificar_password(password: str, hasheada: str) -> bool:
    return bcrypt.checkpw(password.encode(), hasheada.encode())


def crear_token(usuario_id: int, email: str, rol: str, empresa_id: Optional[int]) -> str:
    ahora = datetime.now(timezone.utc)
    payload = {
        "sub": str(usuario_id),
        "email": email,
        "rol": rol,
        "empresa_id": empresa_id,
        "iat": ahora,
        "exp": ahora + timedelta(minutes=MINUTOS_EXPIRACION),
    }
    return jwt.encode(payload, SECRETO_JWT, algorithm=ALGORITMO)


def decodificar_token(token: str) -> dict:
    try:
        return jwt.decode(token, SECRETO_JWT, algorithms=[ALGORITMO])
    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token expirado",
        )
    except jwt.PyJWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token inválido",
        )


def extraer_token(request: Request) -> Optional[str]:
    """Lee el token desde cookie (preferido) o desde header Authorization."""
    token = request.cookies.get("access_token")
    if token:
        return token

    auth = request.headers.get("Authorization", "")
    if auth.startswith("Bearer "):
        return auth[7:].strip()

    return None


# ============================================================
# Dependencias de autenticación
# ============================================================
def usuario_actual(
    request: Request,
    sesion: Session = Depends(obtener_sesion),
):
    """Dependency: devuelve el usuario logueado o lanza 401."""
    token = extraer_token(request)
    if not token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Falta el token de autenticación",
            headers={"WWW-Authenticate": "Bearer"},
        )

    payload = decodificar_token(token)
    usuario_id = int(payload.get("sub", 0))
    usuario = obtener_por_id(sesion, usuario_id)

    if not usuario or not usuario.esta_activo:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Usuario no válido o inactivo",
        )
    return usuario


def requiere_admin(usuario=Depends(usuario_actual)):
    """Dependency: exige que el usuario sea administrador."""
    if usuario.rol != "admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Se requieren permisos de administrador",
        )
    return usuario


def requiere_supervisor(usuario=Depends(usuario_actual)):
    """Dependency: exige que el usuario sea supervisor."""
    if usuario.rol != "supervisor":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Se requieren permisos de supervisor",
        )
    return usuario


def requiere_usuario(usuario=Depends(usuario_actual)):
    """Dependency: exige que el usuario tenga rol 'usuario'."""
    if usuario.rol != "usuario":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Acceso restringido a usuarios con rol 'usuario'",
        )
    return usuario


def verificar_empresa_del_objeto(objeto, usuario) -> None:
    """
    Auxiliar: verifica que objeto.empresa_id coincida con usuario.empresa_id.
    Lanza 403 si no coincide. Usar antes de cualquier modificación.
    """
    if objeto.empresa_id != usuario.empresa_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="No tienes permiso para acceder a recursos de otra empresa",
        )


# ============================================================
# Arranque
# ============================================================
@app.on_event("startup")
def al_arrancar() -> None:
    crear_tablas()
    with SesionLocal() as sesion:
        # Empresa demo (necesaria para usuarios no-admin)
        empresa_demo = obtener_empresa_por_nombre(sesion, "Empresa Demo")
        if not empresa_demo:
            empresa_demo = crear_empresa(sesion, nombre="Empresa Demo")

        # Admin por defecto (sin empresa)
        if not obtener_por_email(sesion, "admin@example.com"):
            crear_usuario(
                sesion,
                nombre="Administrador",
                email="admin@example.com",
                password_hasheada=hashear_password("admin1234"),
                rol="admin",
                empresa_id=None,
            )

        # Supervisor demo
        if not obtener_por_email(sesion, "supervisor@example.com"):
            crear_usuario(
                sesion,
                nombre="Supervisor Demo",
                email="supervisor@example.com",
                password_hasheada=hashear_password("super1234"),
                rol="supervisor",
                empresa_id=empresa_demo.id,
            )

        # Usuario demo
        if not obtener_por_email(sesion, "demo@example.com"):
            crear_usuario(
                sesion,
                nombre="Usuario Demo",
                email="demo@example.com",
                password_hasheada=hashear_password("demo1234"),
                rol="usuario",
                empresa_id=empresa_demo.id,
            )


# ============================================================
# Vistas HTML
# ============================================================
@app.get("/", response_class=HTMLResponse)
def vista_login(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})


@app.get("/recuperar", response_class=HTMLResponse)
def vista_recuperar(request: Request):
    return templates.TemplateResponse("recuperar.html", {"request": request})


@app.get("/dashboard", response_class=HTMLResponse)
def vista_dashboard(
    request: Request,
    sesion: Session = Depends(obtener_sesion),
):
    """
    - Sin sesión → al login.
    - admin → /admin
    - supervisor → /supervisor
    - usuario → dashboard.html
    """
    token = extraer_token(request)
    if not token:
        return RedirectResponse(url="/", status_code=302)

    try:
        payload = decodificar_token(token)
    except HTTPException:
        return RedirectResponse(url="/", status_code=302)

    usuario_id = int(payload.get("sub", 0))
    usuario = obtener_por_id(sesion, usuario_id)

    if not usuario or not usuario.esta_activo:
        return RedirectResponse(url="/", status_code=302)

    if usuario.rol == "admin":
        return RedirectResponse(url="/admin", status_code=302)

    if usuario.rol == "supervisor":
        return RedirectResponse(url="/supervisor", status_code=302)

    return templates.TemplateResponse("dashboard.html", {"request": request})


@app.get("/admin", response_class=HTMLResponse)
def vista_admin(
    request: Request,
    sesion: Session = Depends(obtener_sesion),
):
    """
    - Sin sesión → al login.
    - No admin → al dashboard.
    - Admin → admin.html.
    """
    token = extraer_token(request)
    if not token:
        return RedirectResponse(url="/", status_code=302)

    try:
        payload = decodificar_token(token)
    except HTTPException:
        return RedirectResponse(url="/", status_code=302)

    usuario_id = int(payload.get("sub", 0))
    usuario = obtener_por_id(sesion, usuario_id)

    if not usuario or not usuario.esta_activo:
        return RedirectResponse(url="/", status_code=302)

    if usuario.rol != "admin":
        return RedirectResponse(url="/dashboard", status_code=302)

    return templates.TemplateResponse("admin.html", {"request": request})


@app.get("/supervisor", response_class=HTMLResponse)
def vista_supervisor(
    request: Request,
    sesion: Session = Depends(obtener_sesion),
):
    """
    - Sin sesión → al login.
    - admin → /admin
    - usuario → /dashboard
    - supervisor → supervisor.html
    """
    token = extraer_token(request)
    if not token:
        return RedirectResponse(url="/", status_code=302)

    try:
        payload = decodificar_token(token)
    except HTTPException:
        return RedirectResponse(url="/", status_code=302)

    usuario_id = int(payload.get("sub", 0))
    usuario = obtener_por_id(sesion, usuario_id)

    if not usuario or not usuario.esta_activo:
        return RedirectResponse(url="/", status_code=302)

    if usuario.rol == "admin":
        return RedirectResponse(url="/admin", status_code=302)

    if usuario.rol == "usuario":
        return RedirectResponse(url="/dashboard", status_code=302)

    return templates.TemplateResponse("supervisor.html", {"request": request})


# ============================================================
# API: Autenticación
# ============================================================
@app.post("/auth/login")
def login(
    response: Response,
    email: str = Form(...),
    password: str = Form(...),
    sesion: Session = Depends(obtener_sesion),
):
    usuario = obtener_por_email(sesion, email)

    if not usuario or not verificar_password(password, usuario.password_hasheada):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Credenciales inválidas",
        )

    if not usuario.esta_activo:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Usuario inactivo",
        )

    token = crear_token(usuario.id, usuario.email, usuario.rol, usuario.empresa_id)

    response.set_cookie(
        key="access_token",
        value=token,
        httponly=True,
        samesite="lax",
        max_age=MINUTOS_EXPIRACION * 60,
        path="/",
    )

    return {
        "access_token": token,
        "token_type": "bearer",
        "usuario_id": usuario.id,
        "email": usuario.email,
        "nombre": usuario.nombre,
        "rol": usuario.rol,
        "empresa_id": usuario.empresa_id,
    }


@app.post("/auth/logout")
def logout(response: Response):
    response.delete_cookie(key="access_token", path="/")
    return {"mensaje": "Sesión cerrada"}


@app.get("/auth/yo")
def quien_soy(
    request: Request,
    sesion: Session = Depends(obtener_sesion),
):
    """Devuelve los datos del usuario logueado o 401."""
    token = extraer_token(request)
    if not token:
        raise HTTPException(status_code=401, detail="Sin sesión")

    payload = decodificar_token(token)
    usuario = obtener_por_id(sesion, int(payload.get("sub", 0)))

    if not usuario or not usuario.esta_activo:
        raise HTTPException(status_code=401, detail="Sesión inválida")

    return {
        "usuario_id": usuario.id,
        "email": usuario.email,
        "nombre": usuario.nombre,
        "rol": usuario.rol,
        "empresa_id": usuario.empresa_id,
    }


@app.post("/auth/recuperar")
def solicitar_recuperacion(
    email: str = Form(...),
    sesion: Session = Depends(obtener_sesion),
):
    """
    Genera un código de 6 dígitos y lo guarda en el usuario.
    Devuelve el código en la respuesta (flujo simulado, sin email real).
    Si el email no existe responde igualmente con 200 para no revelar
    qué direcciones están registradas.
    """
    usuario = obtener_por_email(sesion, email)

    # Respuesta genérica aunque el usuario no exista (seguridad)
    if not usuario:
        return {"mensaje": "Si el correo existe, recibirás un código", "codigo_simulado": None}

    codigo = str(random.randint(100000, 999999))
    expiracion = datetime.now(timezone.utc) + timedelta(minutes=MINUTOS_RESET)

    # Guardar sin tzinfo para SQLite (naive UTC)
    guardar_codigo_reset(sesion, usuario.id, codigo, expiracion.replace(tzinfo=None))

    return {"mensaje": "Código generado", "codigo_simulado": codigo}


@app.post("/auth/restablecer")
def restablecer_password(
    email: str = Form(...),
    codigo: str = Form(...),
    nueva_password: str = Form(...),
    sesion: Session = Depends(obtener_sesion),
):
    """
    Valida el código y, si es correcto y no expiró, actualiza la contraseña.
    """
    if len(nueva_password) < 6:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="La contraseña debe tener al menos 6 caracteres",
        )

    usuario = obtener_por_email(sesion, email)

    if not usuario or not usuario.reset_code:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Código inválido o expirado",
        )

    # Comparar código
    if usuario.reset_code != codigo.strip():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Código inválido o expirado",
        )

    # Verificar expiración (la BD guarda naive UTC)
    ahora = datetime.utcnow()
    if usuario.reset_code_expira is None or ahora > usuario.reset_code_expira:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Código inválido o expirado",
        )

    actualizar_password(sesion, usuario.id, hashear_password(nueva_password))

    return {"mensaje": "Contraseña actualizada correctamente"}


# ============================================================
# API: Administración — Usuarios
# ============================================================
@app.get("/admin/usuarios")
def admin_listar_usuarios(
    empresa_id: Optional[int] = None,
    admin=Depends(requiere_admin),
    sesion: Session = Depends(obtener_sesion),
):
    if empresa_id is not None:
        usuarios = listar_usuarios_por_empresa(sesion, empresa_id)
    else:
        usuarios = listar_usuarios(sesion)

    return [
        {
            "id": u.id,
            "nombre": u.nombre,
            "email": u.email,
            "esta_activo": u.esta_activo,
            "rol": u.rol,
            "empresa_id": u.empresa_id,
        }
        for u in usuarios
    ]


@app.post("/admin/usuarios")
def admin_crear_usuario(
    nombre: str = Form(...),
    email: str = Form(...),
    password: str = Form(...),
    rol: str = Form("usuario"),
    empresa_id: Optional[int] = Form(None),
    admin=Depends(requiere_admin),
    sesion: Session = Depends(obtener_sesion),
):
    if not nombre.strip():
        raise HTTPException(status_code=400, detail="El nombre es obligatorio")

    if len(password) < 6:
        raise HTTPException(
            status_code=400,
            detail="La contraseña debe tener al menos 6 caracteres",
        )

    if rol not in ROLES_VALIDOS:
        raise HTTPException(
            status_code=400,
            detail=f"Rol inválido. Debe ser uno de: {', '.join(ROLES_VALIDOS)}",
        )

    if rol in ("supervisor", "usuario") and empresa_id is None:
        raise HTTPException(
            status_code=400,
            detail=f"El campo empresa_id es obligatorio para el rol '{rol}'",
        )

    if rol == "admin":
        empresa_id = None

    if empresa_id is not None and not obtener_empresa_por_id(sesion, empresa_id):
        raise HTTPException(status_code=400, detail="La empresa especificada no existe")

    if obtener_por_email(sesion, email):
        raise HTTPException(status_code=400, detail="El email ya está registrado")

    usuario = crear_usuario(
        sesion,
        nombre=nombre,
        email=email,
        password_hasheada=hashear_password(password),
        rol=rol,
        empresa_id=empresa_id,
    )
    return {
        "mensaje": "Usuario creado",
        "usuario": {
            "id": usuario.id,
            "nombre": usuario.nombre,
            "email": usuario.email,
            "rol": usuario.rol,
            "empresa_id": usuario.empresa_id,
        },
    }


# ============================================================
# API: Administración — Empresas
# ============================================================
@app.get("/admin/empresas")
def admin_listar_empresas(
    admin=Depends(requiere_admin),
    sesion: Session = Depends(obtener_sesion),
):
    empresas = listar_empresas(sesion)
    return [
        {
            "id": e.id,
            "nombre": e.nombre,
            "esta_activa": e.esta_activa,
        }
        for e in empresas
    ]


@app.post("/admin/empresas")
def admin_crear_empresa(
    nombre: str = Form(...),
    admin=Depends(requiere_admin),
    sesion: Session = Depends(obtener_sesion),
):
    if not nombre.strip():
        raise HTTPException(status_code=400, detail="El nombre es obligatorio")

    if obtener_empresa_por_nombre(sesion, nombre):
        raise HTTPException(status_code=400, detail="Ya existe una empresa con ese nombre")

    empresa = crear_empresa(sesion, nombre=nombre)
    return {
        "mensaje": "Empresa creada",
        "empresa": {
            "id": empresa.id,
            "nombre": empresa.nombre,
            "esta_activa": empresa.esta_activa,
        },
    }


# ============================================================
# API: Supervisor — Departamentos
# ============================================================
@app.get("/supervisor/departamentos")
def supervisor_listar_departamentos(
    supervisor=Depends(requiere_supervisor),
    sesion: Session = Depends(obtener_sesion),
):
    departamentos = listar_departamentos_por_empresa(sesion, supervisor.empresa_id)
    return [
        {
            "id": d.id,
            "nombre": d.nombre,
            "empresa_id": d.empresa_id,
        }
        for d in departamentos
    ]


@app.post("/supervisor/departamentos")
def supervisor_crear_departamento(
    nombre: str = Form(...),
    supervisor=Depends(requiere_supervisor),
    sesion: Session = Depends(obtener_sesion),
):
    if not nombre.strip():
        raise HTTPException(status_code=400, detail="El nombre es obligatorio")

    departamento = crear_departamento(sesion, nombre=nombre, empresa_id=supervisor.empresa_id)
    return {
        "mensaje": "Departamento creado",
        "departamento": {
            "id": departamento.id,
            "nombre": departamento.nombre,
            "empresa_id": departamento.empresa_id,
        },
    }


# ============================================================
# API: Supervisor — Cámaras
# ============================================================
@app.get("/supervisor/camaras")
def supervisor_listar_camaras(
    supervisor=Depends(requiere_supervisor),
    sesion: Session = Depends(obtener_sesion),
):
    """Devuelve SOLO las cámaras creadas por este supervisor."""
    camaras = listar_camaras_por_usuario(sesion, supervisor.id)
    return [
        {
            "id": c.id,
            "nombre": c.nombre,
            "url_stream": c.url_stream,
            "empresa_id": c.empresa_id,
            "departamento_id": c.departamento_id,
            "usuario_id": c.usuario_id,
            "esta_activa": c.esta_activa,
        }
        for c in camaras
    ]


@app.post("/supervisor/camaras")
def supervisor_crear_camara(
    nombre: str = Form(...),
    url_stream: str = Form(...),
    departamento_id: int = Form(...),
    supervisor=Depends(requiere_supervisor),
    sesion: Session = Depends(obtener_sesion),
):
    if not nombre.strip():
        raise HTTPException(status_code=400, detail="El nombre es obligatorio")

    if not url_stream.strip():
        raise HTTPException(status_code=400, detail="La URL del stream es obligatoria")

    departamento = obtener_departamento_por_id(sesion, departamento_id)
    if not departamento:
        raise HTTPException(status_code=400, detail="El departamento no existe")

    verificar_empresa_del_objeto(departamento, supervisor)

    camara = crear_camara(
        sesion,
        nombre=nombre,
        url_stream=url_stream,
        empresa_id=supervisor.empresa_id,
        departamento_id=departamento_id,
        usuario_id=supervisor.id,
    )
    return {
        "mensaje": "Cámara creada",
        "camara": {
            "id": camara.id,
            "nombre": camara.nombre,
            "url_stream": camara.url_stream,
            "empresa_id": camara.empresa_id,
            "departamento_id": camara.departamento_id,
            "usuario_id": camara.usuario_id,
            "esta_activa": camara.esta_activa,
        },
    }


@app.delete("/supervisor/camaras/{camara_id}")
def supervisor_eliminar_camara(
    camara_id: int,
    supervisor=Depends(requiere_supervisor),
    sesion: Session = Depends(obtener_sesion),
):
    """Borra una cámara SOLO si pertenece a este supervisor."""
    camara = obtener_camara_por_id(sesion, camara_id)
    if not camara:
        raise HTTPException(status_code=404, detail="Cámara no encontrada")

    if camara.usuario_id != supervisor.id:
        raise HTTPException(
            status_code=403,
            detail="No puedes borrar cámaras de otro supervisor",
        )

    sesion.delete(camara)
    sesion.commit()
    return {"mensaje": "Cámara eliminada", "id": camara_id}


@app.post("/supervisor/camaras/{camara_id}/detectar")
async def supervisor_detectar_objetos(
    camara_id: int,
    archivo: UploadFile = File(...),
    supervisor=Depends(requiere_supervisor),
    sesion: Session = Depends(obtener_sesion),
):
    """
    Recibe un frame (imagen) de una cámara del supervisor, ejecuta YOLO
    y devuelve la lista de objetos detectados.
    """
    # 1) Verificar que la cámara existe y pertenece al supervisor
    camara = obtener_camara_por_id(sesion, camara_id)
    if not camara:
        raise HTTPException(status_code=404, detail="Cámara no encontrada")

    if camara.usuario_id != supervisor.id:
        raise HTTPException(
            status_code=403,
            detail="No puedes analizar cámaras de otro supervisor",
        )

    # 2) Leer y decodificar la imagen
    contents = await archivo.read()
    nparr = np.frombuffer(contents, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

    if img is None:
        return JSONResponse(
            status_code=400,
            content={"error": "Formato de imagen inválido"},
        )

    # 3) Inferencia YOLO
    resultados = modelo_yolo(img, conf=0.5)
    detecciones = []
    for r in resultados:
        for box in r.boxes:
            detecciones.append(
                {
                    "clase": modelo_yolo.names[int(box.cls[0])],
                    "confianza": round(float(box.conf[0]), 3),
                    "bbox": [round(v, 1) for v in box.xyxy[0].tolist()],
                }
            )

    return {
        "camara_id": camara_id,
        "camara_nombre": camara.nombre,
        "total": len(detecciones),
        "detecciones": detecciones,
    }


# ============================================================
# API: Usuario normal
# ============================================================
@app.get("/usuario/informes")
def usuario_informes(
    usuario=Depends(requiere_usuario),
    sesion: Session = Depends(obtener_sesion),
):
    """Devuelve las cámaras activas de la empresa del usuario."""
    camaras = listar_camaras_por_empresa(sesion, usuario.empresa_id)
    return {
        "empresa_id": usuario.empresa_id,
        "camaras": [
            {
                "id": c.id,
                "nombre": c.nombre,
                "url_stream": c.url_stream,
                "departamento_id": c.departamento_id,
                "esta_activa": c.esta_activa,
            }
            for c in camaras
            if c.esta_activa
        ],
    }


# ============================================================
# Healthcheck
# ============================================================
@app.get("/health")
def health():
    return {"status": "ok"}

================================================================================
     LOGIN CON PANEL DE ADMINISTRACIÓN Y SUPERVISIÓN — DOCUMENTACIÓN v1.2
================================================================================
Proyecto:   Sistema de login con roles, aislamiento por empresa y visualización
            de cámaras en directo
Versión:    1.2
Fecha:      2026-10-13
Stack:      Python 3.12 · FastAPI · SQLAlchemy · bcrypt · PyJWT · Jinja2
Frontend:   HTML + CSS + JS puro (sin frameworks) + hls.js (solo HLS)
Base datos: SQLite (login.db)
Seguridad:  JWT en cookie httpOnly + validación en servidor por rol
Generado:   Claude (Anthropic)
================================================================================


================================================================================
1. RESUMEN EJECUTIVO
================================================================================

La v1.2 parte de la v1.1 (login con 3 roles y aislamiento por empresa) y añade
visualización de cámaras en directo y aislamiento por usuario dentro de cada
empresa.

Cambios principales:

  1. Aislamiento por usuario
     Cada cámara queda ligada al usuario que la creó (columna usuario_id).
     Un supervisor solo ve las cámaras que él mismo registró, no las de otros
     supervisores de su empresa.

  2. Botones de acción en la tabla de cámaras
     Cada fila tiene: ▶ Ver  y  🗑 Borrar

  3. Modal de visualización
     Al pulsar ▶ Ver se abre un modal que reproduce el stream.

  4. Soporte de tres formatos
     - HLS (.m3u8)   vía hls.js
     - MJPEG         vía <img> (fallback automático si <video> falla)
     - RTSP          detectado y avisado al usuario (navegador no lo reproduce)

  5. Borrado seguro
     Un supervisor solo puede borrar sus propias cámaras.

  6. Corrección crítica de SQLAlchemy
     Se unificó el Base declarativo (antes había dos distintos, lo que impedía
     que crear_tablas() creara las tablas).

Alcance v1.2:

  - Login de usuarios existentes
  - Panel admin: gestión de usuarios y empresas
  - Panel supervisor: gestión de departamentos y cámaras propias
  - Visualización de cámaras en modal (HLS + MJPEG)
  - Borrado de cámaras propias
  - Logout con borrado de cookie

Fuera de alcance (para v1.3):

  - Edición de cámaras desde el panel
  - Edición/desactivación de usuarios
  - Conversión RTSP → HLS dentro del backend (FFmpeg embebido)
  - Paginación en listados
  - Tests automatizados
  - Migración a Postgres + Alembic


================================================================================
2. ESTRUCTURA DEL PROYECTO
================================================================================

login-simple/
│
├── base_de_datos/                    ← Capa de datos
│   ├── __init__.py
│   ├── conexion.py                   ← ÚNICA FUENTE DE Base (v1.2)
│   ├── modelos.py                    ← importa Base desde conexion.py (v1.2)
│   ├── usuarios.py
│   ├── empresas.py
│   ├── departamentos.py
│   └── camaras.py                    ← +usuario_id, +listar_por_usuario (v1.2)
│
├── templates/
│   ├── login.html
│   ├── dashboard.html
│   ├── admin.html
│   └── supervisor.html               ← +modal, +<img> fallback (v1.2)
│
├── static/
│   ├── style.css                     ← +bloque .modal (v1.2)
│   ├── login.js
│   ├── dashboard.js
│   ├── admin.js
│   └── supervisor.js                 ← +abrirModalCamara, +cerrarModalCamara,
│                                       +destruirHls, +botones Ver/Borrar (v1.2)
│
├── main.py                           ← +DELETE /supervisor/camaras/{id} (v1.2)
├── requirements.txt
├── iniciar.bat
├── login.db                          ← SQLite (se recrea al arrancar)
├── CHANGELOG.md
└── DOCUMENTACION_v1.2.txt            ← este archivo


Notas importantes:

  - "base_de_datos" SIEMPRE en minúsculas (Python case-sensitive).
  - Si renombras la carpeta en Windows cambiando solo mayúsculas, hazlo en
    dos pasos:
        ren Base_de_datos base_de_datos_temp
        ren base_de_datos_temp base_de_datos


================================================================================
3. INSTALACIÓN
================================================================================

Requisitos:

  - Python 3.11, 3.12 o 3.13 (NO 3.14+, por compatibilidad con bcrypt)
  - pip actualizado
  - Conexión a internet solo la primera vez

PASO 1 — Automático (recomendado):

    Doble clic en iniciar.bat
    El .bat se encarga de:
      - Detectar/instalar Python 3.12
      - Crear el entorno virtual
      - Instalar dependencias
      - Verificar estructura del proyecto
      - Arrancar Uvicorn en http://localhost:8000

PASO 2 — Manual (si prefieres hacerlo a mano):

    Windows:
        python -m venv venv
        venv\Scripts\activate
        pip install -r requirements.txt
        uvicorn main:app --reload

    Linux / macOS:
        python3 -m venv venv
        source venv/bin/activate
        pip install -r requirements.txt
        uvicorn main:app --reload

PASO 3 — Abrir en el navegador:

    http://localhost:8000

Credenciales demo (se crean automáticamente al arrancar):

    ┌────────────────────┬───────────────────────┬───────────┐
    │ Rol                │ Email                 │ Password  │
    ├────────────────────┼───────────────────────┼───────────┤
    │ Administrador      │ admin@example.com     │ admin1234 │
    │ Supervisor         │ supervisor@example.com│ super1234 │
    │ Usuario común      │ demo@example.com      │ demo1234  │
    └────────────────────┴───────────────────────┴───────────┘


================================================================================
4. DEPENDENCIAS (requirements.txt)
================================================================================

fastapi==0.115.0            Framework web asíncrono
uvicorn[standard]==0.32.0   Servidor ASGI con extras
jinja2==3.1.4               Motor de plantillas HTML
pydantic[email]==2.9.2      Validación de datos + emails
bcrypt==4.2.0               Hash de contraseñas
PyJWT==2.9.0                Generación y validación de JWT
sqlalchemy==2.0.35          ORM para la base de datos
python-multipart==0.0.12    OBLIGATORIO para Form(...)

Extra en el frontend (vía CDN, sin instalar nada):
    hls.js                  Solo si usas streams .m3u8

⚠️  NO quitar python-multipart. Sin él, los formularios devuelven error 500.


================================================================================
5. CAPA DE BASE DE DATOS
================================================================================


--------------------------------------------------------------------------------
5.1 base_de_datos/conexion.py
--------------------------------------------------------------------------------

Responsabilidad:
  - Crear el engine de SQLAlchemy
  - Configurar SessionLocal
  - Definir el Base ÚNICO del proyecto              ← CRÍTICO en v1.2
  - Proveer obtener_sesion() (dependency de FastAPI)
  - Proveer crear_tablas() para inicializar la BD

Contenido clave:

    Base = declarative_base()                        ← ÚNICO Base

    def crear_tablas() -> None:
        from base_de_datos import modelos            ← registra los modelos
        Base.metadata.create_all(bind=motor)

⚠️  CAMBIO v1.2: en v1.1 había dos declarative_base() distintos (uno en
    conexion.py y otro en modelos.py). Como los modelos se registraban en
    el de modelos.py, Base.metadata.create_all() del conexion.py estaba
    vacío y NO creaba ninguna tabla. Ahora solo existe un Base en todo el
    proyecto, definido aquí, e importado desde modelos.py.


--------------------------------------------------------------------------------
5.2 base_de_datos/modelos.py
--------------------------------------------------------------------------------

⚠️  CAMBIO v1.2: ya no define su propio Base. Lo importa de conexion.py:

    from base_de_datos.conexion import Base

Tabla "usuarios":
    id                 → Integer, primary key, indexado
    nombre             → String, no nulo
    email              → String, único, indexado, no nulo
    password_hasheada  → String, no nulo
    esta_activo        → Boolean, por defecto True
    rol                → String, no nulo, default "usuario"
    empresa_id         → Integer, FK → empresas.id, nullable, indexado

Tabla "empresas":
    id                 → Integer, primary key
    nombre             → String, único, no nulo
    esta_activa        → Boolean, default True

Tabla "departamentos":
    id                 → Integer, primary key
    nombre             → String, no nulo
    empresa_id         → Integer, FK → empresas.id, no nulo, indexado

Tabla "camaras":
    id                 → Integer, primary key
    nombre             → String, no nulo
    url_stream         → String, no nulo
    empresa_id         → Integer, FK → empresas.id, no nulo, indexado
    departamento_id    → Integer, FK → departamentos.id, no nulo, indexado
    usuario_id         → Integer, FK → usuarios.id, NULLABLE, indexado  ← NUEVO v1.2
    esta_activa        → Boolean, default True

⚠️  Si modificas alguna tabla:
      1. Borra login.db
      2. Reinicia el servidor
    SQLite NO migra cambios de esquema automáticamente.


--------------------------------------------------------------------------------
5.3 base_de_datos/camaras.py
--------------------------------------------------------------------------------

Funciones disponibles:

  crear_camara(sesion, nombre, url_stream, empresa_id, departamento_id,
               usuario_id=None, esta_activa=True) -> CamaraORM
      Crea una cámara. usuario_id es el creador.        ← MODIFICADO v1.2

  obtener_por_id(sesion, camara_id) -> Optional[CamaraORM]

  listar_por_empresa(sesion, empresa_id) -> List[CamaraORM]

  listar_por_usuario(sesion, usuario_id) -> List[CamaraORM]
      Devuelve SOLO las cámaras creadas por ese usuario. ← NUEVA v1.2

  listar_por_departamento(sesion, departamento_id) -> List[CamaraORM]

  actualizar_camara(sesion, camara_id, **campos) -> Optional[CamaraORM]
      Campos válidos: nombre, url_stream, empresa_id, departamento_id,
                      usuario_id, esta_activa.          ← +usuario_id v1.2


================================================================================
6. APLICACIÓN PRINCIPAL (main.py)
================================================================================


--------------------------------------------------------------------------------
6.1 Configuración
--------------------------------------------------------------------------------

SECRETO_JWT = "cambia-esto-en-produccion"
ALGORITMO = "HS256"
MINUTOS_EXPIRACION = 60
ROLES_VALIDOS = {"admin", "supervisor", "usuario"}


--------------------------------------------------------------------------------
6.2 Utilidades de seguridad
--------------------------------------------------------------------------------

hashear_password(password) -> str
verificar_password(password, hasheada) -> bool
crear_token(usuario_id, email, rol, empresa_id) -> str
decodificar_token(token) -> dict
extraer_token(request) -> Optional[str]
    Lee el token desde la cookie "access_token" (preferido) o desde
    Authorization: Bearer <token> (fallback).


--------------------------------------------------------------------------------
6.3 Dependencias de autenticación
--------------------------------------------------------------------------------

usuario_actual(request, sesion)
    → Devuelve el usuario logueado o 401.

requiere_admin(usuario)
    → Exige rol "admin". 403 si no.

requiere_supervisor(usuario)
    → Exige rol "supervisor". 403 si no.

requiere_usuario(usuario)
    → Exige rol "usuario". 403 si no.

verificar_empresa_del_objeto(objeto, usuario)
    → Comprueba que objeto.empresa_id == usuario.empresa_id. 403 si no.


--------------------------------------------------------------------------------
6.4 Evento de arranque
--------------------------------------------------------------------------------

@app.on_event("startup")
def al_arrancar():
    1. crear_tablas()
    2. Crea "Empresa Demo" si no existe.
    3. Crea admin@example.com (rol=admin, empresa=None).
    4. Crea supervisor@example.com (rol=supervisor, empresa=Demo).
    5. Crea demo@example.com (rol=usuario, empresa=Demo).


--------------------------------------------------------------------------------
6.5 Rutas HTML
--------------------------------------------------------------------------------

GET /              → login.html
GET /dashboard     → dashboard.html (redirige a /admin o /supervisor según rol)
GET /admin         → admin.html (redirige si no es admin)
GET /supervisor    → supervisor.html (redirige si no es supervisor)


--------------------------------------------------------------------------------
6.6 API de autenticación
--------------------------------------------------------------------------------

POST /auth/login
    FormData: email, password
    200 OK → { access_token, usuario_id, email, nombre, rol, empresa_id }
    401 → "Credenciales inválidas"
    403 → "Usuario inactivo"

POST /auth/logout
    Borra la cookie access_token.

GET /auth/yo
    Devuelve los datos del usuario logueado o 401.


--------------------------------------------------------------------------------
6.7 API de administración
--------------------------------------------------------------------------------

GET /admin/usuarios[?empresa_id=N]
    Lista usuarios (filtrados por empresa si se pasa el query param).

POST /admin/usuarios
    FormData: nombre, email, password, rol, empresa_id

GET /admin/empresas
POST /admin/empresas
    FormData: nombre


--------------------------------------------------------------------------------
6.8 API de supervisor — Departamentos
--------------------------------------------------------------------------------

GET /supervisor/departamentos
    Lista departamentos de la empresa del supervisor.

POST /supervisor/departamentos
    FormData: nombre


--------------------------------------------------------------------------------
6.9 API de supervisor — Cámaras
--------------------------------------------------------------------------------

GET /supervisor/camaras
    ⚠️  MODIFICADO v1.2: ahora usa listar_camaras_por_usuario(supervisor.id)
        en lugar de listar_camaras_por_empresa(...). Devuelve SOLO las cámaras
        creadas por el supervisor autenticado.
    Respuesta: [{id, nombre, url_stream, empresa_id, departamento_id,
                 usuario_id, esta_activa}, ...]

POST /supervisor/camaras
    FormData: nombre, url_stream, departamento_id
    ⚠️  MODIFICADO v1.2: pasa usuario_id=supervisor.id a crear_camara().

DELETE /supervisor/camaras/{camara_id}
    ⚠️  NUEVO v1.2.
    - Requiere rol supervisor.
    - 404 si la cámara no existe.
    - 403 si camara.usuario_id != supervisor.id
    - 200 → {"mensaje": "Cámara eliminada", "id": N}


--------------------------------------------------------------------------------
6.10 API de usuario normal
--------------------------------------------------------------------------------

GET /usuario/informes
    Devuelve las cámaras activas de la empresa del usuario.


--------------------------------------------------------------------------------
6.11 Healthcheck
--------------------------------------------------------------------------------

GET /health → {"status": "ok"}


================================================================================
7. FLUJO DE AUTENTICACIÓN
================================================================================

1. Usuario abre http://localhost:8000 → login.html
2. Ingresa email/contraseña → login.js envía POST /auth/login
3. Backend valida y responde con rol:
     - admin      → /admin
     - supervisor → /supervisor
     - usuario    → /dashboard
4. El JWT se guarda en cookie httpOnly (el JS no puede leerlo).
5. En cada petición posterior, la cookie viaja automáticamente.
6. Backend valida token y rol en CADA endpoint protegido.


================================================================================
8. TEMPLATES
================================================================================


--------------------------------------------------------------------------------
8.1 templates/login.html
--------------------------------------------------------------------------------

Sin cambios en v1.2.


--------------------------------------------------------------------------------
8.2 templates/dashboard.html
--------------------------------------------------------------------------------

Sin cambios en v1.2.


--------------------------------------------------------------------------------
8.3 templates/admin.html
--------------------------------------------------------------------------------

Sin cambios en v1.2.


--------------------------------------------------------------------------------
8.4 templates/supervisor.html
--------------------------------------------------------------------------------

⚠️  MODIFICADO v1.2. Se añadió al final del <body>, antes de los <script>:

    <div id="modal-camara" class="modal" aria-hidden="true" role="dialog">
      <div class="modal-contenido">
        <header class="modal-header">
          <h2 id="modal-titulo">Cámara</h2>
          <button id="modal-cerrar" ...>✕</button>
        </header>
        <div class="modal-video-wrapper">
          <video id="modal-video" controls autoplay muted playsinline></video>
          <img id="modal-img" alt="Stream de cámara" style="display:none; ..." />
          <p id="modal-error" class="mensaje mensaje--error" role="alert"></p>
        </div>
        <p id="modal-url" class="modal-url"></p>
      </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/hls.js@1"></script>
    <script src="/static/supervisor.js"></script>

IDs críticos del modal:
    modal-camara, modal-titulo, modal-cerrar,
    modal-video, modal-img, modal-error, modal-url


================================================================================
9. ESTILOS (static/style.css)
================================================================================

REGLA FUNDAMENTAL:
    SOLO EXISTE UN ARCHIVO CSS EN TODO EL PROYECTO: static/style.css
    Todas las páginas lo cargan con:
        <link rel="stylesheet" href="/static/style.css" />

NO crear archivos CSS por página. NO usar <style> inline.

Estructura del archivo (orden actual):

   1) Reset
   2) Variables CSS en :root
   3) Base (body, tipografía, fondo)
   4) Layout (.pagina)
   5) Componentes reutilizables:
        .tarjeta, .tarjeta--login, .tarjeta--dashboard, .tarjeta--admin
        .encabezado, .campo, .campo--flex, .campo-ayuda
        .boton, .boton--primario, .boton--peligro, .boton--secundario,
        .boton--sm, .boton--auto, .spinner
        .mensaje, .pie, .caja-token, .dashboard-acciones, .dashboard-camaras
        .select-campo
   6) Admin:
        .admin-seccion, .admin-subtitulo, .admin-seccion-header,
        .admin-form, .admin-form--inline
        .tabla-usuarios, .tabla, .tabla-vacia
        .badge, .badge--admin, .badge--supervisor, .badge--usuario,
        .badge--activo, .badge--inactivo, .badge--empresa
        .admin-footer, .enlace-volver
   7) Supervisor:
        .supervisor-form, .supervisor-tabla
   8) ⚠️ NUEVO v1.2 — Modal de cámara:
        .modal                 → contenedor fijo a pantalla completa
        .modal[aria-hidden="false"] → display: flex
        .modal-contenido       → caja blanca/oscura
        .modal-header
        .modal-video-wrapper   → 16:9 con fondo negro
        .modal-video-wrapper video,
        .modal-video-wrapper img
        .modal-url
        .mensaje--error        → color rojo
        .tabla-acciones        → flex con gap para los botones Ver/Borrar
   9) Animaciones (@keyframes fadeInUp, spin)
  10) Responsive (@media max-width)
  11) Modo oscuro (@media prefers-color-scheme)


================================================================================
10. JAVASCRIPT
================================================================================


--------------------------------------------------------------------------------
10.1 static/login.js
--------------------------------------------------------------------------------

Sin cambios en v1.2.


--------------------------------------------------------------------------------
10.2 static/dashboard.js
--------------------------------------------------------------------------------

Sin cambios en v1.2.


--------------------------------------------------------------------------------
10.3 static/admin.js
--------------------------------------------------------------------------------

Sin cambios en v1.2.


--------------------------------------------------------------------------------
10.4 static/supervisor.js
--------------------------------------------------------------------------------

⚠️  MODIFICADO v1.2.

Referencias nuevas al principio del archivo:

    const modalEl       = document.getElementById("modal-camara");
    const modalVideo    = document.getElementById("modal-video");
    const modalImg      = document.getElementById("modal-img");
    const modalTituloEl = document.getElementById("modal-titulo");
    const modalUrlEl    = document.getElementById("modal-url");
    const modalErrorEl  = document.getElementById("modal-error");
    const modalCerrarEl = document.getElementById("modal-cerrar");

cargarCamaras() — modificada:

    Se añadió la columna "Acciones" en el <thead> y, en cada fila,
    dos botones:
        <button data-accion="ver"    data-id data-nombre data-url>▶ Ver</button>
        <button data-accion="borrar" data-id data-nombre>🗑 Borrar</button>

    Delegación de eventos:
      - Botón "ver"    → llama a abrirModalCamara({ nombre, url })
      - Botón "borrar" → confirm(), DELETE /supervisor/camaras/{id}, recarga

Funciones nuevas:

    abrirModalCamara({ nombre, url })
        1. Limpia estado previo, destruye HLS si había.
        2. Oculta <video> e <img>.
        3. Según la URL:
             rtsp://     → muestra aviso (navegador no lo reproduce)
             *.m3u8      → reproduce con hls.js (si está cargado)
             http(s)://  → intenta <video>; si en 2.5s no arranca,
                           cambia a <img src="..."> (MJPEG)
        4. Abre el modal (aria-hidden="false").

    cerrarModalCamara()
        - Pausa el <video>, limpia src.
        - Limpia src del <img> y lo oculta.
        - Destruye HLS si existe.
        - Cierra el modal.

    destruirHls()
        - Destruye hlsInstance si existe.

Listeners del modal:
    - Click en ✕
    - Click fuera del .modal-contenido
    - Tecla Escape

⚠️  Todos los fetch DEBEN incluir credentials: "include".


================================================================================
11. RUTAS DE LA APLICACIÓN
================================================================================

MÉTODO   RUTA                                  DESCRIPCIÓN              QUIÉN
------   -----------------------------------   ----------------------   --------------
GET      /                                     Login (HTML)             público
GET      /dashboard                            Dashboard (HTML)         autenticado
GET      /admin                                Panel admin (HTML)       solo admin
GET      /supervisor                           Panel supervisor (HTML)  solo supervisor
POST     /auth/login                           Autenticación            público
POST     /auth/logout                          Cerrar sesión            autenticado
GET      /auth/yo                              Datos del usuario        autenticado
GET      /admin/usuarios                       Listar usuarios          solo admin
POST     /admin/usuarios                       Crear usuario            solo admin
GET      /admin/empresas                       Listar empresas          solo admin
POST     /admin/empresas                       Crear empresa            solo admin
GET      /supervisor/departamentos             Listar departamentos     solo supervisor
POST     /supervisor/departamentos             Crear departamento       solo supervisor
GET      /supervisor/camaras                   Listar cámaras propias   solo supervisor
POST     /supervisor/camaras                   Crear cámara             solo supervisor
DELETE   /supervisor/camaras/{id}              Borrar cámara propia     solo supervisor  ← NUEVO v1.2
GET      /usuario/informes                     Cámaras de la empresa    solo usuario
GET      /health                               Healthcheck              público
GET      /docs                                 Swagger UI               desarrollo
GET      /static/*                             Archivos estáticos       público


================================================================================
12. SEGURIDAD POR CAPAS
================================================================================

El control de acceso se aplica en varios niveles:

  Capa 1 — Frontend (JS)
      login.js redirige según rol tras el login.
      supervisor.js verifica el rol al arrancar.

  Capa 2 — Vistas HTML (servidor)
      vista_supervisor() redirige si no es supervisor.
      vista_admin() redirige si no es admin.

  Capa 3 — Endpoints (servidor)
      requiere_supervisor() valida token + rol en cada endpoint.
      camara.usuario_id == supervisor.id verifica propiedad en DELETE.

  Capa 4 — Aislamiento de datos
      Listados filtran por usuario_id (no por empresa_id) para el supervisor.
      El cliente nunca envía empresa_id ni usuario_id: se extraen del token.

Tabla de escenarios:

  ┌───────────────────────────────────────────────┬──────────────────────┐
  │ Escenario                                     │ Resultado            │
  ├───────────────────────────────────────────────┼──────────────────────┤
  │ Supervisor A crea cámara                      │ Se guarda con su id  │
  │ Supervisor B lista cámaras                    │ NO ve la de A        │
  │ Supervisor B intenta DELETE de la cámara de A │ 403 Forbidden        │
  │ Usuario común intenta GET /supervisor/camaras │ 403 Forbidden        │
  │ Sin sesión intenta GET /supervisor/camaras    │ 401 Unauthorized     │
  │ Editar localStorage para decir supervisor     │ No sirve (valida BD) │
  │ Robar la cookie desde otro navegador          │ No puede leerla      │
  └───────────────────────────────────────────────┴──────────────────────┘


================================================================================
13. FLUJO DE VISUALIZACIÓN DE UNA CÁMARA
================================================================================

1. Usuario supervisor pulsa ▶ Ver en una fila
2. JS abre el modal y llama a abrirModalCamara({ nombre, url })
3. Según la URL:
     - rtsp://     → muestra aviso (no soportado por navegador)
     - *.m3u8      → reproduce con hls.js
     - http(s)://  → intenta <video>, si falla en 2.5s → cambia a <img> (MJPEG)
4. Al cerrar (✕, Escape, click fuera):
     - Detiene <video>
     - Limpia src del <img>
     - Destruye hls.js si estaba activo

Recomendación de URLs según emisor:

  ┌───────────────────────────────┬────────────────────────────────────────┐
  │ Emisor                        │ URL a guardar                          │
  ├───────────────────────────────┼────────────────────────────────────────┤
  │ IP Webcam (Android)           │ http://IP:8080/video      (MJPEG)      │
  │ Cámara IP con MJPEG HTTP      │ http://IP/video o /mjpeg  (MJPEG)      │
  │ MediaMTX / go2rtc (proxy HLS) │ http://servidor:8888/cam1/index.m3u8   │
  │ Cámara solo RTSP              │ Requiere proxy a MJPEG/HLS primero     │
  └───────────────────────────────┴────────────────────────────────────────┘

⚠️  RTSP NO se reproduce en ningún navegador. Necesita un proxy (MediaMTX,
    go2rtc, FFmpeg) que lo convierta a MJPEG o HLS.


================================================================================
14. REGLAS PARA NO ROMPER EL CÓDIGO
================================================================================

REGLA 1 — UN SOLO CSS GLOBAL
    Todo el estilo vive en static/style.css.

REGLA 2 — SEPARACIÓN POR CAPAS
    base_de_datos/  → SOLO SQL
    templates/      → SOLO HTML
    static/         → SOLO CSS y JS
    main.py         → Rutas FastAPI y utilidades

REGLA 3 — NOMBRES EN MINÚSCULAS
    base_de_datos (SIEMPRE en minúsculas).

REGLA 4 — IDs EN HTML Y getElementById EN JS
    IDs críticos del modal:
        modal-camara, modal-titulo, modal-cerrar,
        modal-video, modal-img, modal-error, modal-url

REGLA 5 — SCRIPT CORRECTO POR PÁGINA
    login.html     → login.js
    dashboard.html → dashboard.js
    admin.html     → admin.js
    supervisor.html → supervisor.js
    ⚠️  NO cargar login.js en admin.html ni supervisor.html.

REGLA 6 — FORMULARIOS SIEMPRE CON id
    El <form> DEBE tener id para que el JS lo intercepte.

REGLA 7 — e.preventDefault() PRIMERO
    En cada addEventListener("submit", async (e) => {...}).

REGLA 8 — credentials: "include" EN FETCH
    Todo fetch a endpoints con cookie DEBE tenerlo.

REGLA 9 — __init__.py EN CARPETAS DE PAQUETES

REGLA 10 — BASE DE DATOS
    El archivo login.db se crea solo al arrancar.
    Si modificas la estructura de una tabla:
        1. Borra login.db
        2. Reinicia el servidor

REGLA 11 — SECRETO_JWT
    Si lo cambias, TODOS los tokens quedan inválidos.

REGLA 12 — UN SOLO declarative_base EN TODO EL PROYECTO
    ⚠️  NUEVA v1.2.
    El Base vive en base_de_datos/conexion.py.
    modelos.py lo importa. NUNCA definas otro declarative_base().

REGLA 13 — NO DUPLICAR CÓDIGO
    Antes de crear una función, revisa:
        base_de_datos/camaras.py:  crear_camara, obtener_por_id,
                                   listar_por_empresa, listar_por_usuario,
                                   listar_por_departamento, actualizar_camara
        main.py:                   hashear_password, verificar_password,
                                   crear_token, decodificar_token, extraer_token


================================================================================
15. ERRORES COMUNES Y SOLUCIONES
================================================================================

ERROR: "no such table: empresas"
CAUSA: crear_tablas() no está registrando los modelos en el Base.
FIX:   Verificar que modelos.py importa Base desde conexion.py
       y NO tiene su propio declarative_base().

ERROR: "table camaras has no column named usuario_id"
CAUSA: La BD es anterior a v1.2 y no tiene la columna nueva.
FIX 1: Borrar login.db y reiniciar (pierdes datos).
FIX 2: ALTER TABLE camaras ADD COLUMN usuario_id INTEGER;
       UPDATE camaras SET usuario_id = <id_supervisor> WHERE usuario_id IS NULL;

ERROR: El modal se abre pero no se ve el vídeo
CAUSA 1: URL apunta a la página HTML de la cámara, no al stream.
FIX 1:   Usar la URL del stream directo (ej: /video, /mjpeg, .m3u8).
CAUSA 2: Es MJPEG y el <video> no lo soporta.
FIX 2:   El código ya hace fallback a <img> en 2.5s. Esperar.
CAUSA 3: Es RTSP.
FIX 3:   Montar MediaMTX/go2rtc y guardar la URL convertida.

ERROR: net::ERR_CONNECTION_REFUSED
CAUSA: La cámara está apagada, cambió de IP o el puerto está bloqueado.

ERROR: Modal no se abre / no pasa nada al pulsar ▶ Ver
CAUSA 1: El modal no está en el HTML.
FIX 1:   Verificar <div id="modal-camara"> antes del <script>.
CAUSA 2: supervisor.js cacheado.
FIX 2:   Ctrl + Shift + R.
CAUSA 3: Error JS previo.
FIX 3:   Revisar F12 → Console.

ERROR: bucle infinito /auth/yo → /admin → /
CAUSA: supervisor.html carga login.js en vez de supervisor.js.

ERROR: "Form data requires python-multipart to be installed"
FIX: pip install python-multipart==0.0.12

ERROR: Login devuelve 500
FIX: Mirar la consola de uvicorn → traceback completo.

ERROR: El CSS no se aplica
FIX: Verificar <link rel="stylesheet" href="/static/style.css"> en el HTML
     y que main.py monte /static.


================================================================================
16. PRUEBAS DE FUNCIONAMIENTO
================================================================================

PRUEBA 1 — Servidor arriba
    iniciar.bat → debe mostrar "Uvicorn running on http://127.0.0.1:8000"

PRUEBA 2 — Healthcheck
    curl http://localhost:8000/health → {"status":"ok"}

PRUEBA 3 — Login correcto (supervisor)
    curl -X POST http://localhost:8000/auth/login ^
      -d "email=supervisor@example.com" ^
      -d "password=super1234" -i
    → 200 OK + Set-Cookie + JSON con rol: "supervisor"

PRUEBA 4 — Login incorrecto
    → 401 {"detail":"Credenciales inválidas"}

PRUEBA 5 — Flujo supervisor
    1. Login supervisor@example.com / super1234
    2. Redirige a /supervisor
    3. Crear departamento
    4. Crear cámara
    5. Pulsar ▶ Ver → modal abre y muestra el stream

PRUEBA 6 — Aislamiento entre supervisores
    1. Login como supervisor A, crear cámara X
    2. Logout
    3. Login como supervisor B (creado por admin)
    4. B NO debe ver la cámara X
    5. B intenta DELETE /supervisor/camaras/{id_de_X} → 403

PRUEBA 7 — Borrado
    1. Login supervisor A
    2. Pulsar 🗑 Borrar en una cámara propia → desaparece
    3. Pulsar 🗑 Borrar en una cámara ajena → 403

PRUEBA 8 — Logout
    1. Cerrar sesión → vuelve a / y no
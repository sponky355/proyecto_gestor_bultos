// ============================================================
// Panel de administración
// ============================================================

console.log("[admin.js] Cargado en:", window.location.href);

const form = document.getElementById("crear-usuario-form");
const nombreInput = document.getElementById("nombre");
const emailInput = document.getElementById("email");
const passwordInput = document.getElementById("password");
const esAdminInput = document.getElementById("es_admin");
const submitBtn = document.getElementById("submit-btn");
const messageEl = document.getElementById("message");
const tablaEl = document.getElementById("tabla-usuarios");
const refrescarBtn = document.getElementById("refrescar-btn");
const logoutBtn = document.getElementById("logout-btn");

console.log("[admin.js] Elementos encontrados:", {
  form: !!form,
  nombre: !!nombreInput,
  email: !!emailInput,
  password: !!passwordInput,
  submitBtn: !!submitBtn,
  message: !!messageEl,
  tabla: !!tablaEl,
  refrescar: !!refrescarBtn,
  logout: !!logoutBtn,
});

// ------------------------------------------------------------
// Helpers
// ------------------------------------------------------------
function showMessage(texto, tipo = "error") {
  if (!messageEl) return;
  messageEl.textContent = texto;
  messageEl.className = `mensaje ${tipo}`;
}

function setLoading(cargando) {
  if (!submitBtn) return;
  submitBtn.disabled = cargando;
  submitBtn.classList.toggle("loading", cargando);
  const txt = submitBtn.querySelector(".btn-text");
  if (txt) txt.textContent = cargando ? "Creando..." : "Crear usuario";
}

function limpiarFormulario() {
  if (!form) return;
  form.reset();
  if (nombreInput) nombreInput.focus();
}

function escapeHtml(str) {
  if (!str) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

// ------------------------------------------------------------
// Cargar lista de usuarios
// ------------------------------------------------------------
async function cargarUsuarios() {
  if (!tablaEl) {
    console.error("[admin.js] No existe #tabla-usuarios");
    return;
  }

  tablaEl.innerHTML = '<p class="tabla-vacia">Cargando usuarios...</p>';

  try {
    const res = await fetch("/admin/usuarios", {
      credentials: "include",
    });

    console.log("[admin.js] GET /admin/usuarios →", res.status);

    if (res.status === 401) {
      console.log("[admin.js] 401 → redirigiendo a /");
      window.location.href = "/";
      return;
    }

    if (res.status === 403) {
      console.log("[admin.js] 403 → redirigiendo a /dashboard");
      alert("Sin permisos de administrador.");
      window.location.href = "/dashboard";
      return;
    }

    const data = await res.json();

    if (!data.length) {
      tablaEl.innerHTML =
        '<p class="tabla-vacia">No hay usuarios registrados.</p>';
      return;
    }

    const filas = data
      .map(
        (u) => `
          <tr>
            <td>${u.id}</td>
            <td>${escapeHtml(u.nombre) || '<em class="texto-muted">—</em>'}</td>
            <td>${escapeHtml(u.email)}</td>
            <td>
              ${u.es_admin
                ? '<span class="badge badge--admin">Admin</span>'
                : '<span class="badge">Usuario</span>'}
            </td>
            <td>
              ${u.esta_activo
                ? '<span class="badge badge--activo">Activo</span>'
                : '<span class="badge badge--inactivo">Inactivo</span>'}
            </td>
          </tr>`
      )
      .join("");

    tablaEl.innerHTML = `
      <table class="tabla">
        <thead>
          <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Email</th>
            <th>Rol</th>
            <th>Estado</th>
          </tr>
        </thead>
        <tbody>${filas}</tbody>
      </table>`;
  } catch (err) {
    console.error("[admin.js] Error cargando usuarios:", err);
    tablaEl.innerHTML = `<p class="tabla-vacia">Error: ${err.message}</p>`;
  }
}

// ------------------------------------------------------------
// Crear usuario
// ------------------------------------------------------------
if (form) {
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    showMessage("", "");

    const nombre = nombreInput.value.trim();
    const email = emailInput.value.trim();
    const password = passwordInput.value;

    if (!nombre || !email || !password) {
      showMessage("Completa todos los campos");
      return;
    }

    if (password.length < 6) {
      showMessage("La contraseña debe tener al menos 6 caracteres");
      return;
    }

    setLoading(true);

    try {
      const datos = new FormData();
      datos.append("nombre", nombre);
      datos.append("email", email);
      datos.append("password", password);
      datos.append("es_admin", esAdminInput.checked ? "true" : "false");

      const res = await fetch("/admin/usuarios", {
        method: "POST",
        credentials: "include",
        body: datos,
      });

      const data = await res.json().catch(() => ({}));

      if (!res.ok) {
        throw new Error(data.detail || "No se pudo crear el usuario");
      }

      showMessage(
        `Usuario "${data.usuario.nombre}" creado correctamente`,
        "success"
      );
      limpiarFormulario();
      cargarUsuarios();
    } catch (err) {
      showMessage(err.message);
    } finally {
      setLoading(false);
    }
  });
}

// ------------------------------------------------------------
// Eventos auxiliares
// ------------------------------------------------------------
if (refrescarBtn) {
  refrescarBtn.addEventListener("click", cargarUsuarios);
}

if (logoutBtn) {
  logoutBtn.addEventListener("click", async () => {
    try {
      await fetch("/auth/logout", {
        method: "POST",
        credentials: "include",
      });
    } catch {
      /* ignorar */
    }
    localStorage.clear();
    window.location.href = "/";
  });
}

[nombreInput, emailInput, passwordInput].forEach((input) => {
  if (!input) return;
  input.addEventListener("input", () => {
    input.classList.remove("invalid");
    if (messageEl && messageEl.classList.contains("error")) {
      messageEl.textContent = "";
      messageEl.className = "mensaje";
    }
  });
});

// ------------------------------------------------------------
// Carga inicial: verificar sesión + rol
// ------------------------------------------------------------
(async () => {
  console.log("[admin.js] Verificando sesión con /auth/yo...");
  try {
    const res = await fetch("/auth/yo", { credentials: "include" });
    console.log("[admin.js] GET /auth/yo →", res.status);

    if (!res.ok) {
      console.log("[admin.js] Sin sesión → redirigiendo a /");
      window.location.href = "/";
      return;
    }

    const data = await res.json();
    console.log("[admin.js] Datos de /auth/yo:", data);

    if (!data.es_admin) {
      console.log("[admin.js] No es admin → redirigiendo a /dashboard");
      alert("No tienes permisos para acceder a esta página.");
      window.location.href = "/dashboard";
      return;
    }

    console.log("[admin.js] Es admin ✅ → cargando usuarios");
    cargarUsuarios();
  } catch (err) {
    console.error("[admin.js] Error en verificación inicial:", err);
    window.location.href = "/";
  }
})();
// Verificar sesión con el backend
(async () => {
  try {
    const res = await fetch("/auth/yo", { credentials: "include" });
    if (!res.ok) {
      window.location.href = "/";
      return;
    }

    const data = await res.json();

    // Si por alguna razón llegó un admin aquí, mandarlo al panel
    if (data.es_admin) {
      window.location.href = "/admin";
      return;
    }

    const display = data.nombre
      ? `${data.nombre} (${data.email})`
      : data.email;

    document.getElementById("user-email").textContent = display;
    document.getElementById("token-display").textContent =
      "(guardado en cookie httpOnly)";
  } catch {
    window.location.href = "/";
  }
})();

// Logout
document.getElementById("logout-btn").addEventListener("click", async () => {
  try {
    await fetch("/auth/logout", {
      method: "POST",
      credentials: "include",
    });
  } catch {
    /* ignorar */
  }
  localStorage.clear();
  window.location.href = "/";
});
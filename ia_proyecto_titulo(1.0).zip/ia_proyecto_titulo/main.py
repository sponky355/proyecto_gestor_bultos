from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

import bcrypt
import jwt
from fastapi import (
    Depends,
    FastAPI,
    Form,
    HTTPException,
    Request,
    Response,
    status,
)
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from base_de_datos.conexion import SesionLocal, crear_tablas, obtener_sesion
from base_de_datos.usuarios import (
    crear_usuario,
    listar_usuarios,
    obtener_por_email,
    obtener_por_id,
)

# ============================================================
# Configuración
# ============================================================
SECRETO_JWT = "cambia-esto-en-produccion"
ALGORITMO = "HS256"
MINUTOS_EXPIRACION = 60

BASE_DIR = Path(__file__).resolve().parent
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))

app = FastAPI(title="Login Simple + Admin")
app.mount(
    "/static",
    StaticFiles(directory=str(BASE_DIR / "static")),
    name="static",
)


# ============================================================
# Utilidades de seguridad
# ============================================================
def hashear_password(password: str) -> str:
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()


def verificar_password(password: str, hasheada: str) -> bool:
    return bcrypt.checkpw(password.encode(), hasheada.encode())


def crear_token(usuario_id: int, email: str, es_admin: bool) -> str:
    ahora = datetime.now(timezone.utc)
    payload = {
        "sub": str(usuario_id),
        "email": email,
        "es_admin": es_admin,
        "iat": ahora,
        "exp": ahora + timedelta(minutes=MINUTOS_EXPIRACION),
    }
    return jwt.encode(payload, SECRETO_JWT, algorithm=ALGORITMO)


def decodificar_token(token: str) -> dict:
    try:
        return jwt.decode(token, SECRETO_JWT, algorithms=[ALGORITMO])
    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token expirado",
        )
    except jwt.PyJWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token inválido",
        )


def extraer_token(request: Request) -> Optional[str]:
    """Lee el token desde cookie (preferido) o desde header Authorization."""
    token = request.cookies.get("access_token")
    if token:
        return token

    auth = request.headers.get("Authorization", "")
    if auth.startswith("Bearer "):
        return auth[7:].strip()

    return None


# ============================================================
# Dependencias de autenticación
# ============================================================
def usuario_actual(
    request: Request,
    sesion: Session = Depends(obtener_sesion),
):
    """Dependency: devuelve el usuario logueado o lanza 401."""
    token = extraer_token(request)
    if not token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Falta el token de autenticación",
            headers={"WWW-Authenticate": "Bearer"},
        )

    payload = decodificar_token(token)
    usuario_id = int(payload.get("sub", 0))
    usuario = obtener_por_id(sesion, usuario_id)

    if not usuario or not usuario.esta_activo:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Usuario no válido o inactivo",
        )
    return usuario


def requiere_admin(usuario=Depends(usuario_actual)):
    """Dependency: exige que el usuario sea administrador (verificado en BD)."""
    if not usuario.es_admin:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Se requieren permisos de administrador",
        )
    return usuario


# ============================================================
# Arranque
# ============================================================
@app.on_event("startup")
def al_arrancar() -> None:
    crear_tablas()
    with SesionLocal() as sesion:
        if not obtener_por_email(sesion, "admin@example.com"):
            crear_usuario(
                sesion,
                nombre="Administrador",
                email="admin@example.com",
                password_hasheada=hashear_password("admin1234"),
                es_admin=True,
            )
        if not obtener_por_email(sesion, "demo@example.com"):
            crear_usuario(
                sesion,
                nombre="Usuario Demo",
                email="demo@example.com",
                password_hasheada=hashear_password("demo1234"),
                es_admin=False,
            )


# ============================================================
# Vistas HTML
# ============================================================
@app.get("/", response_class=HTMLResponse)
def vista_login(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})


@app.get("/dashboard", response_class=HTMLResponse)
def vista_dashboard(
    request: Request,
    sesion: Session = Depends(obtener_sesion),
):
    """
    Dashboard de usuario común.
    - Sin sesión → al login.
    - Admin → directo a /admin (nunca ve el dashboard).
    - Usuario común → sirve dashboard.html.
    """
    token = extraer_token(request)
    if not token:
        return RedirectResponse(url="/", status_code=302)

    try:
        payload = decodificar_token(token)
    except HTTPException:
        return RedirectResponse(url="/", status_code=302)

    usuario_id = int(payload.get("sub", 0))
    usuario = obtener_por_id(sesion, usuario_id)

    if not usuario or not usuario.esta_activo:
        return RedirectResponse(url="/", status_code=302)

    if usuario.es_admin:
        return RedirectResponse(url="/admin", status_code=302)

    return templates.TemplateResponse("dashboard.html", {"request": request})


@app.get("/admin", response_class=HTMLResponse)
def vista_admin(
    request: Request,
    sesion: Session = Depends(obtener_sesion),
):
    """
    Panel de administración.
    - Sin sesión → al login.
    - Usuario común → al dashboard.
    - Admin → sirve admin.html.
    """
    token = extraer_token(request)
    if not token:
        return RedirectResponse(url="/", status_code=302)

    try:
        payload = decodificar_token(token)
    except HTTPException:
        return RedirectResponse(url="/", status_code=302)

    usuario_id = int(payload.get("sub", 0))
    usuario = obtener_por_id(sesion, usuario_id)

    if not usuario or not usuario.esta_activo:
        return RedirectResponse(url="/", status_code=302)

    if not usuario.es_admin:
        return RedirectResponse(url="/dashboard", status_code=302)

    return templates.TemplateResponse("admin.html", {"request": request})


# ============================================================
# API: Autenticación
# ============================================================
@app.post("/auth/login")
def login(
    response: Response,
    email: str = Form(...),
    password: str = Form(...),
    sesion: Session = Depends(obtener_sesion),
):
    usuario = obtener_por_email(sesion, email)

    if not usuario or not verificar_password(password, usuario.password_hasheada):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Credenciales inválidas",
        )

    if not usuario.esta_activo:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Usuario inactivo",
        )

    token = crear_token(usuario.id, usuario.email, usuario.es_admin)

    response.set_cookie(
        key="access_token",
        value=token,
        httponly=True,
        samesite="lax",
        max_age=MINUTOS_EXPIRACION * 60,
        path="/",
    )

    return {
        "access_token": token,
        "token_type": "bearer",
        "usuario_id": usuario.id,
        "email": usuario.email,
        "nombre": usuario.nombre,
        "es_admin": usuario.es_admin,
    }


@app.post("/auth/logout")
def logout(response: Response):
    response.delete_cookie(key="access_token", path="/")
    return {"mensaje": "Sesión cerrada"}


@app.get("/auth/yo")
def quien_soy(
    request: Request,
    sesion: Session = Depends(obtener_sesion),
):
    """Devuelve los datos del usuario logueado o 401."""
    token = extraer_token(request)
    if not token:
        raise HTTPException(status_code=401, detail="Sin sesión")

    payload = decodificar_token(token)
    usuario = obtener_por_id(sesion, int(payload.get("sub", 0)))

    if not usuario or not usuario.esta_activo:
        raise HTTPException(status_code=401, detail="Sesión inválida")

    return {
        "usuario_id": usuario.id,
        "email": usuario.email,
        "nombre": usuario.nombre,
        "es_admin": usuario.es_admin,
    }


# ============================================================
# API: Administración
# ============================================================
@app.get("/admin/usuarios")
def admin_listar_usuarios(
    admin=Depends(requiere_admin),
    sesion: Session = Depends(obtener_sesion),
):
    usuarios = listar_usuarios(sesion)
    return [
        {
            "id": u.id,
            "nombre": u.nombre,
            "email": u.email,
            "esta_activo": u.esta_activo,
            "es_admin": u.es_admin,
        }
        for u in usuarios
    ]


@app.post("/admin/usuarios")
def admin_crear_usuario(
    nombre: str = Form(...),
    email: str = Form(...),
    password: str = Form(...),
    es_admin: bool = Form(False),
    admin=Depends(requiere_admin),
    sesion: Session = Depends(obtener_sesion),
):
    if not nombre.strip():
        raise HTTPException(status_code=400, detail="El nombre es obligatorio")

    if len(password) < 6:
        raise HTTPException(
            status_code=400,
            detail="La contraseña debe tener al menos 6 caracteres",
        )

    if obtener_por_email(sesion, email):
        raise HTTPException(status_code=400, detail="El email ya está registrado")

    usuario = crear_usuario(
        sesion,
        nombre=nombre,
        email=email,
        password_hasheada=hashear_password(password),
        es_admin=es_admin,
    )
    return {
        "mensaje": "Usuario creado",
        "usuario": {
            "id": usuario.id,
            "nombre": usuario.nombre,
            "email": usuario.email,
            "es_admin": usuario.es_admin,
        },
    }


# ============================================================
# Healthcheck
# ============================================================
@app.get("/health")
def health():
    return {"status": "ok"}
from typing import List, Optional

from sqlalchemy.orm import Session

from base_de_datos.modelos import UsuarioORM


def obtener_por_email(sesion: Session, email: str) -> Optional[UsuarioORM]:
    return (
        sesion.query(UsuarioORM)
        .filter(UsuarioORM.email == email.lower())
        .first()
    )


def obtener_por_id(sesion: Session, usuario_id: int) -> Optional[UsuarioORM]:
    return sesion.query(UsuarioORM).filter(UsuarioORM.id == usuario_id).first()


def listar_usuarios(sesion: Session) -> List[UsuarioORM]:
    return sesion.query(UsuarioORM).order_by(UsuarioORM.id.asc()).all()


def crear_usuario(
    sesion: Session,
    email: str,
    password_hasheada: str,
    nombre: str = "",
    esta_activo: bool = True,
    es_admin: bool = False,
) -> UsuarioORM:
    usuario = UsuarioORM(
        nombre=nombre.strip(),
        email=email.lower(),
        password_hasheada=password_hasheada,
        esta_activo=esta_activo,
        es_admin=es_admin,
    )
    sesion.add(usuario)
    sesion.commit()
    sesion.refresh(usuario)
    return usuario
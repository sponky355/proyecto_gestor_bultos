from sqlalchemy import Boolean, Column, Integer, String

from base_de_datos.conexion import Base


class UsuarioORM(Base):
    __tablename__ = "usuarios"

    id = Column(Integer, primary_key=True, index=True)
    nombre = Column(String, nullable=False, default="")
    email = Column(String, unique=True, index=True, nullable=False)
    password_hasheada = Column(String, nullable=False)
    esta_activo = Column(Boolean, default=True, nullable=False)
    es_admin = Column(Boolean, default=False, nullable=False)